import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CurrentLocationMap extends StatefulWidget{
  @override
  State<StatefulWidget> createState()=>CurrentLocationMapState();
}

class CurrentLocationMapState extends State<CurrentLocationMap>{

  GoogleMapController? map;
  StreamSubscription<Position>? sub;
  LatLng? mySelf;
  final markerID=MarkerId("Rabbil");

  // Initial Location
  @override
  void initState(){
    super.initState();
    initLocation();
  }

  Future initLocation() async{


    // Step 01: Permission Manage & Check
    LocationPermission permission = await Geolocator.checkPermission();
    if(permission==LocationPermission.denied){
      permission= await Geolocator.requestPermission();
    }
    if(permission==LocationPermission.denied || permission==LocationPermission.deniedForever){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Location Permission Missing"))
      );
      return;
    }

    // Step 02: Ensure Location Services On
    final enabled= await Geolocator.isLocationServiceEnabled();
    if(!enabled){
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Please Enable Location Service"))
      );
      return;
    }

    final LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 100,
    );

    // Step 03:Capture the Initial Position
    Position position = await Geolocator.getCurrentPosition(locationSettings: locationSettings);
    updatePosition(position);

    // Stream Position Updates
    sub?.cancel();
    sub=Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best,
          distanceFilter: 5
        ),
    ).listen((p)=>updatePosition(p));
  }


  // Step 04: Update Position
  void updatePosition(Position p){
    final here= LatLng(p.latitude, p.longitude);
    setState(() {
      mySelf=here;
    });
  }

  // Animate The MAP
  Future animateTo(LatLng target) async{
    if(map==null) return;
    await map!.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: target,zoom: 14)
      )
    );
  }

  
  
  
  @override
  Widget build(BuildContext context) {
    
    final start=mySelf ?? const LatLng(23.777176, 90.399452);
    Set<Marker> marker={};
    if(mySelf!=null){
       marker={
        Marker(
            markerId: markerID,
            position: mySelf!,
            infoWindow: InfoWindow(title: "RABBIL")
        )
      };
    }
    
    return Scaffold(
      appBar: AppBar(title: Text("My Location"),),
      body: Stack(
        children: [
          GoogleMap(
              initialCameraPosition: CameraPosition(target: start,zoom: 14),
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
              markers: marker,
          )
        ],
      ),
    );
    
    
    
  }


}