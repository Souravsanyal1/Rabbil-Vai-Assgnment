import 'package:flutter/material.dart';
import 'CurrentLocationMap.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Flutter My Current Location",
      home: CurrentLocationMap()
    );
  }

}